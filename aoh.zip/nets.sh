#!/bin/bash

vde_switch -sock /tmp/net1.vde

vde_switch -sock /tmp/net2.vde

vde_switch -sock /tmp/net3.vde
vde_switch -sock /tmp/net4.vde