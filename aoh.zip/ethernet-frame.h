
#ifndef __ETHERNET_FRAME_H
#define __ETHERNET_FRAME_H

#include <stdint.h>




#endif